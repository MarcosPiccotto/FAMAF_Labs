#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "command.h"
#include "builtin.h"
#include "tests/syscall_mock.h"

bool exit_yn = false;

//FUNCIONES DE COMANDOS

static void cd(scommand cmd){
    int scmd_l = scommand_length(cmd);
    char* home = getenv("HOME");
    if(scmd_l==1 ){ // cd sin argumentos, va al home
        if(chdir(home) != 0){
            printf("chdir(home) error\n");
        }
    }
    else if(scmd_l <= 2){ // cd con un argumento (ruta de directorio)
        scommand_pop_front(cmd);
        char* command = scommand_to_string(cmd);
        if(strcmp(command, "~") == 0){ // cd ~ va al home
            if(chdir(home) != 0){
                printf("chdir ~ error\n");                
            };
        }
        else if(chdir(command) != 0){ // cd con cualquier otra ruta
            printf("chdir error\n");
        }
        free(command);
    }
    else{ // más de 2 argumentos, comando inválido
        printf("to much arguments\n");
    }
}


static void wolo(scommand cmd){ // imprime un wolo ascii jajajsdaj
    const char* wolo_txt = "./text/wolo.txt";
    FILE* file = NULL;
    file = fopen(wolo_txt, "r");
    if(file == NULL){
        perror("Error opening wolo.txt\n");
        return;
    }

    char* lines = NULL;
    size_t bufer = 0;
    ssize_t read;


    while((read = getline(&lines, &bufer, file)) != -1){
        printf("%s", lines);
    }
    
    free(lines);
    fclose(file);
    printf("\n");
}

static void help(scommand cmd){ // imprime el txt del help
    const char* help_txt = "./text/help.txt";
    FILE* file = NULL;
    file = fopen(help_txt, "r");
    if(file == NULL){
        perror("Error opening help.txt\n");
        return;
    }

    char* lines = NULL;
    size_t bufer = 0;
    ssize_t read;


    while((read = getline(&lines, &bufer, file)) != -1){
        printf("%s", lines);
    }
    
    free(lines);
    fclose(file);
    printf("\n");

}

static void exit_cmd(scommand cmd){
    const char* exit_txt = "./text/exit.txt";
    FILE* file = NULL;
    file = fopen(exit_txt, "r");
    if(file == NULL){
        perror("Error opening exit.txt\n");
        return;
    }

    char* lines = NULL;
    size_t bufer = 0;
    ssize_t read;


    while((read = getline(&lines, &bufer, file)) != -1){ // imprime un mensaje de despedida
        printf("%s", lines);
    }
    
    free(lines);
    fclose(file);
    printf("\n");
    exit_yn = true; // cambia el valor de la variable global de exit
    (void)cmd;
}

bool get_exit(void){
    return(exit_yn);
}

/*----------------------------*/

//DEFINICION DICCIONARIO
//se accede a la función que ejecuta el comando correspondiente a la key
typedef struct{
        const char* cmd_key;
        void (*cmd_fun)(scommand);
}Dictionary;

Dictionary internal_commands[]={
    {"cd", cd},
    {"wolo", wolo},
    {"help", help},
    {"exit", exit_cmd}
};

size_t inter_cmd_length = sizeof(internal_commands)/sizeof(internal_commands[0]); //cantidad de comandos implementados

/*----------------------------*/

//FUNCIONES BUILTIN

bool builtin_is_internal(scommand cmd){
    assert(cmd != NULL);
    bool is_internal = false;

    for(size_t i=0; i<inter_cmd_length; ++i){ //is_internal = true si coincide con alguna de las keys del diccionario
        is_internal = is_internal || (strcmp(scommand_front(cmd),internal_commands[i].cmd_key)==0);
    }
    return is_internal;
}

bool builtin_alone(pipeline p){
    assert(p != NULL);
    return((pipeline_length(p) == 1) && (builtin_is_internal(pipeline_front(p))));
}

void builtin_run(scommand cmd){
    assert(builtin_is_internal(cmd));
    const char* command = scommand_front(cmd);

    for(size_t i = 0; i<inter_cmd_length; ++i){ //si encuentra una key que coincide con el comando pasado, ejecuta la función correspondiente
        if(strcmp(command, internal_commands[i].cmd_key) == 0){
            internal_commands[i].cmd_fun(cmd);
        }
    }
}

/*----------------------------*/