#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h> // Necesario para la función getcwd
#include <limits.h> // Necesario para definir PATH_MAX
#include <string.h> // Necesario para strlen

#include "command.h"
#include "execute.h"
#include "parser.h"
#include "parsing.h"
#include "builtin.h"

#include "obfuscated.h"

// Definiciones en caso de que no estén disponibles
#ifndef HOST_NAME_MAX
#define HOST_NAME_MAX 256
#endif

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

static void show_prompt(void)
{
    char hostname[HOST_NAME_MAX + 1];
    char cwd[PATH_MAX];

    if (gethostname(hostname, sizeof(hostname)) == 0)
    {
        printf("%s:", hostname);
    }

    if (getcwd(cwd, sizeof(cwd)) != NULL)
    {
        char *home_dir = getenv("HOME");

        if (home_dir != NULL && strncmp(cwd, home_dir, strlen(home_dir)) == 0)
        {
            // La ruta de trabajo comienza con la ruta de inicio de sesión, reemplaza con ~
            printf("~%s$ ", cwd + strlen(home_dir));
        }
        else
        {
            printf("%s$ ", cwd);
        }
    }
    else
    {
        printf("mybash$ ");
    }

    fflush(stdout);
}

int main(int argc, char *argv[])
{
    pipeline pipe;
    Parser input;
    bool quit = false;

    input = parser_new(stdin);
    while (!quit)
    {
        // Lo comentamos porque no lo resolvimos 
        // ping_pong_loop(NULL);
        show_prompt();
        pipe = parse_pipeline(input);
        if (pipe != NULL)
        {
            execute_pipeline(pipe);
            pipeline_destroy(pipe);
        }
        quit = parser_at_eof(input) || get_exit();
    }
    parser_destroy(input);
    input = NULL;
    return EXIT_SUCCESS;
}