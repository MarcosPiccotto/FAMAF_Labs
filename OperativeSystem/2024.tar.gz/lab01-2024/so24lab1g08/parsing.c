#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>

#include "parsing.h"
#include "parser.h"
#include "command.h"

static scommand parse_scommand(Parser p)
{
    assert(p != NULL);
    // si no hay mas comandos
    if (parser_at_eof(p))
    {
        return NULL;
    }

    scommand scmd = scommand_new();
    bool is_eof = false;
    char *arg = NULL;
    arg_kind_t type;

    do
    {
        // salteamos espacios en blanco
        parser_skip_blanks(p);

        arg = parser_next_argument(p, &type);
        if (arg != NULL)
        {
            // determinamos el tipo de comando
            switch (type)
            {
            case ARG_NORMAL:
                scommand_push_back(scmd, arg);
                break;
            case ARG_INPUT:
                scommand_set_redir_in(scmd, arg);
                break;
            case ARG_OUTPUT:
                scommand_set_redir_out(scmd, arg);
                break;
            }
            is_eof = parser_at_eof(p);
        }
        // mientras no se llegue al final
        // o el argumento es invalido
    } while (!is_eof && arg != NULL);

    return scmd;
}

pipeline parse_pipeline(Parser p)
{
    assert(p != NULL && !parser_at_eof(p));

    pipeline result = pipeline_new();
    bool error = false, bg = false;
    bool another_pipe = true;
    scommand cmd = NULL;

    while (another_pipe && !error)
    {
        cmd = parse_scommand(p);
        // comando invalido
        if (cmd == NULL || scommand_is_empty(cmd))
        {
            error = true;
            pipeline_destroy(result);
            // limpiar el input
            parser_garbage(p, &error);
            return NULL;
        }
        // comando valido
        pipeline_push_back(result, cmd);

        // integra el uso de && como pipes
        parser_op_background(p, &bg);
        parser_op_background(p, &another_pipe);
        if (!another_pipe)
        {
            parser_op_pipe (p, &another_pipe);
            // & | (expresion invalida)
            if (bg && another_pipe)
            {
                printf ("Expresion invalida\n");
                error = true;
                pipeline_destroy(result);
                // limpiar el input
                parser_garbage(p, &error);
                return NULL;
            }
        }
    }
    pipeline_set_wait(result, !bg);

    /* Consumir todo lo que hay inclusive el \n */
    parser_garbage(p, &error);
    
    return result;
}