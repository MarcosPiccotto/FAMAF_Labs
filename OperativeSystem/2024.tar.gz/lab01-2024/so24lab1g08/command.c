#include <stdbool.h> 
#include <assert.h>
#include <stdio.h>
#include <glib.h>
#include <string.h>
#include "command.h"
#include "strextra.h"

struct scommand_s
{
    GList *cmd;
    char *out;
    char *in;
};


scommand scommand_new(void)
{
    scommand new = malloc(sizeof(struct scommand_s));
    assert(new != NULL);
    new->cmd = NULL;
    new->out = NULL;
    new->in = NULL;
    return (new);
}

scommand scommand_destroy(scommand self){
    assert(self != NULL);
    //libera la lista
    g_list_free_full(self->cmd, (GDestroyNotify)*free);
    if (self->out != NULL) 
    {
        free(self->out);
        self->out = NULL;
    }
    if (self->in != NULL) {
        free(self->in);
        self->in = NULL;
    }
    free(self);
    self = NULL;
    assert(self == NULL);
    return self; 
}

void scommand_push_back(scommand self, char * argument)
{
    assert(self != NULL);
    assert(argument != NULL);
    //Agrega el argumento al final de la lista
    self->cmd = g_list_append(self->cmd, argument);
    assert (!scommand_is_empty(self));
}

void scommand_pop_front(scommand self)
{
    assert(self != NULL && self->cmd != NULL);
    //Libera el nodo
    g_free(self->cmd->data);
    //Apunta al proximo elem
    self->cmd = g_list_delete_link (self->cmd, self->cmd);
}

void scommand_set_redir_in(scommand self, char * filename)
{
    assert(self != NULL);
    if (self->in != NULL)
    {
        free(self->in);
        self->in = NULL;
    }
    self->in = filename;
}
void scommand_set_redir_out(scommand self, char * filename)
{
    assert(self != NULL);
    if (self->out != NULL)
    {
        free(self->out);
        self->out = NULL;
    }
    self->out = filename;
}

/* Proyectores */

bool scommand_is_empty(const scommand self)
{
    assert(self != NULL);
    return (g_list_length (self->cmd) == 0);
}

unsigned int scommand_length(const scommand self)
{
    assert(self != NULL);
    return (g_list_length(self->cmd)); 
}

char * scommand_front(const scommand self)
{
    assert(self != NULL && !scommand_is_empty(self));
    //Obtiene el primer elem
    char *result = (char *)g_list_first(self->cmd)->data;
    assert (result != NULL);
    return (result);
}

char * scommand_get_redir_in(const scommand self)
{
    assert(self != NULL);
    return (self->in);
}
char * scommand_get_redir_out(const scommand self)
{
    assert(self != NULL);
    return (self->out);
}

char * scommand_to_string(const scommand self)
{
    assert(self != NULL);
    char *result = strdup ("");
    if (g_list_length(self->cmd) == 0)
    {
        //sc vacio
        return (result);
    }
    //Variable para recorrer la lista
    GList *cmd_copy = self->cmd;
    char *killme;
    while (cmd_copy != NULL)
    {
        killme = result;
        result = strmerge (result, cmd_copy->data);
        //Libero la memoria anterior de result
        free(killme);
        if (cmd_copy->next != NULL) 
        {
            //Agrega espacios entre flags
            killme = result;
            result = strmerge (result," ");
            free(killme);
        }
        cmd_copy = cmd_copy->next;
    }
    if (self->in != NULL) {
        killme = result;
        result = strmerge (result, " <");
        free(killme);
        killme = result;
        result = strmerge (result, self->in);
        free(killme);
    }
    if (self->out != NULL) {
        killme = result;
        result = strmerge (result, " >");
        free(killme);
        killme = result;
        result = strmerge (result, self->out);
        free(killme);
    }
    assert (scommand_is_empty(self) || scommand_get_redir_in (self) == NULL ||
            scommand_get_redir_out (self) == NULL || strlen(result) > 0);
    return (result);
}



struct pipeline_s {
    GList *pipe;
    bool bg;
};

pipeline pipeline_new(void)
{
    pipeline new = malloc(sizeof(struct pipeline_s));
    assert(new != NULL);
    new->pipe = NULL;
    new->bg = true;
    return (new);
}

//Funcion auxiliar para liberar los sc
static void free_sc(scommand sc)
{
    scommand_destroy(sc);
}

pipeline pipeline_destroy(pipeline self)
{
    assert(self != NULL);
    //Libero la lista
    g_list_free_full(self->pipe,(GDestroyNotify)&free_sc);
    free(self);
    self = NULL;
    return (self);
}

/* Modificadores */

void pipeline_push_back(pipeline self, scommand sc)
{
    assert(self != NULL);
    assert(sc != NULL);
    self->pipe = g_list_append(self->pipe, sc);
}

void pipeline_pop_front(pipeline self)
{
    assert(self != NULL && self->pipe != NULL);
    //Libero el primer nodo
    scommand_destroy(self->pipe->data);
    //Apunto al proximo nodo
    self->pipe = g_list_delete_link(self->pipe, self->pipe);
}

void pipeline_set_wait(pipeline self, const bool w)
{
    assert(self != NULL);
    self->bg = w;
}
/* Proyectores */

bool pipeline_is_empty(const pipeline self)
{
    assert(self != NULL);
    return (g_list_length (self->pipe) == 0);
}

unsigned int pipeline_length(const pipeline self)
{
    assert(self != NULL);
    return (g_list_length (self->pipe));
}

scommand pipeline_front(const pipeline self)
{
    assert(self != NULL && !pipeline_is_empty (self));
    scommand sc;
    sc = self->pipe->data;
    assert(sc != NULL);
    return (sc);
}

bool pipeline_get_wait(const pipeline self)
{
    assert(self != NULL);
    return (self->bg);
}
char * pipeline_to_string(const pipeline self)
{
    assert(self != NULL);
    char *result = strdup ("");
    if (g_list_length (self->pipe) == 0)
    {
    	//Pipeline vacio
        return (result);
    }
    char *sc;
    char *killme;
    //Variable para recorrer el pipelind
    GList *pipe_cpy = self->pipe;
    while (pipe_cpy != NULL) {
        sc = scommand_to_string(pipe_cpy->data);
        killme = result;
        result = strmerge (result,sc);
        free(sc);
        //Libero la memoria anterior de result
        free(killme);
        if (pipe_cpy->next != NULL)
        {
            //Agrega las pipes " | " entre sc
            killme = result;
            result = strmerge(result, " | ");
            free(killme);
        }
        pipe_cpy = pipe_cpy->next;
    }
    if (!self->bg) 
    {
        killme = result;
        result = strmerge(result, " &");
        free(killme);
    }
    return (result);
}
