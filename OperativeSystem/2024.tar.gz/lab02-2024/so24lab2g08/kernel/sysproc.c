#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "semaphore.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0; // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if (growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n)
  {
    if (killed(myproc()))
    {
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

static semaphore sems[MAX_SEMS];

uint64
sys_sem_open(void)
{
  int name, value;
  argint(0, &name);
  argint(1, &value);
  
  acquire(&sems[name].lock);
  if (name < 1 || name > MAX_SEMS - 1 || value < 0 || value > MAX_SEM_VALUE)
  {
    return 0; // Error, semaphore out of range
  }

  if(sems[name].is_open)
  {
    // Semaphore already opened
    release(&sems[name].lock);
    return 0; 
  }
  
  sems[name].value = value;
  sems[name].is_open = 1;
  
  release(&sems[name].lock);
  return name;
}

uint64
sys_sem_up(void)
{
  int name;
  argint(0, &name);

  if (name < 1 || name > MAX_SEMS - 1)
  {
    return 0; // Error, semaphore out of range
  }

  acquire(&sems[name].lock);
  if (!sems[name].is_open)
  {
    // Semaphore already closed
    release(&sems[name].lock);
    return 0;
  }

  // If semaphore was in 0, wakes up a process
  if (sems[name].value == 0)
  {
    wakeup(&sems[name]);
  }
  ++sems[name].value;

  release(&sems[name].lock);
  return 1;
}

uint64
sys_sem_down(void)
{
  int name;
  argint(0, &name);

  if (name < 1 || name > MAX_SEMS - 1)
  {
    return 0; // Error, semaphore out of range
  }

  acquire(&sems[name].lock);
  if (!sems[name].is_open)
  {
    // Semaphore already closed
    release(&sems[name].lock);
    return 0;
  }
  // If semaphore value == 0 then sleeps the process
  while (sems[name].value == 0)
  {
    sleep(&sems[name], &sems[name].lock);
  }
  --sems[name].value;

  release(&sems[name].lock);
  return 1;
}

uint64
sys_sem_close(void)
{
  int name;
  argint(0, &name);

  if (name < 1 || name > MAX_SEMS - 1)
  {
    return 0; // Error, semaphore out of range
  }

  acquire(&sems[name].lock);
  if (!sems[name].is_open)
  {
    // Semaphore already closed
    release(&sems[name].lock);
    return 0;
  }

  sems[name].is_open = 0;
  sems[name].value = -1;

  release(&sems[name].lock);
  return 1;
}