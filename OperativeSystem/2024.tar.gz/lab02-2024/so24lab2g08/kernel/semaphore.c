#include "types.h"
#include "param.h"
#include "riscv.h"
#include "spinlock.h"
#include "defs.h"
#include "semaphore.h"

static semaphore sems[MAX_SEMS];

void
init_sems(void)
{

  for (int i = 0; i < MAX_SEMS; ++i)
  {
    sems[i].is_open = 0;
    sems[i].value = -1;

    initlock(&sems[i].lock, "semaphore");
  }
}

int
sem_open(int sem, int value)
{
  acquire(&sems[sem].lock);
  if (sem < 1 || sem > MAX_SEMS - 1 || value < 0 || value > MAX_SEM_VALUE)
  {
    return 0; // Error, semaphore out of range
  }

  if(sems[sem].is_open)
  {
    // Semaphore already opened
    release(&sems[sem].lock);
    return 0;
  }

  sems[sem].value = value;
  sems[sem].is_open = 1;

  release(&sems[sem].lock);
  return sem;
}

int
sem_up(int sem)
{
  if (sem < 1 || sem > MAX_SEMS - 1)
  {
    return 0; // Error, semaphore out of range
  }

  acquire(&sems[sem].lock);
  if (!sems[sem].is_open)
  {
    // Semaphore already closed
    release(&sems[sem].lock);
    return 0;
  }

  // If semaphore was in 0, wakes up a process
  if (sems[sem].value == 0)
  {
    wakeup(&sems[sem]);
  }
  ++sems[sem].value;

  release(&sems[sem].lock);
  return 1;
}

int
sem_down(int sem)
{
  if (sem < 1 || sem > MAX_SEMS - 1)
  {
    return 0; // Error, semaphore out of range
  }

  acquire(&sems[sem].lock);
  if (!sems[sem].is_open)
  {
    // Semaphore already closed
    release(&sems[sem].lock);
    return 0;
  }
  // If semaphore value == 0 then sleeps the process
  while (sems[sem].value == 0)
  {
    sleep(&sems[sem], &sems[sem].lock);
  }
  --sems[sem].value;

  release(&sems[sem].lock);
  return 1;
}

int
sem_close(int sem)
{
  if (sem < 1 || sem > MAX_SEMS - 1)
  {
    return 0; // Error, semaphore out of range
  }

  acquire(&sems[sem].lock);
  if (!sems[sem].is_open)
  {
    // Semaphore already closed
    release(&sems[sem].lock);
    return 0;
  }

  sems[sem].is_open = 0;
  sems[sem].value = -1;

  release(&sems[sem].lock);
  return 1;
}

