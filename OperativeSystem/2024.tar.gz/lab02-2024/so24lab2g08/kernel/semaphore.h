#ifndef SEMAPHORE_H
#define SEMAPHORE_H

#include "types.h"

#define MAX_SEM_VALUE 1
// Position 0 is reserved
#define MAX_SEMS (20 + 1)

typedef struct semaphore
{
    int value;
    int is_open;
    struct spinlock lock;
} semaphore;

int
sem_open(int, int);

int
sem_up(int);

int
sem_down(int);

int
sem_close(int);

#endif // SEMAPHORE_H