#include "kernel/types.h"
#include "kernel/riscv.h"
#include "kernel/spinlock.h"
#include "kernel/defs.h"
#include "kernel/semaphore.h"

// Auxiliar function to convert an string to an integer.
static int 
atoi(const char *str)
{
    int result = 0;
    int sign = 1;
    // Handle negative sign
    if (*str == '-')
    {
        sign = -1;
        str++;
    }
    // Go over each char of the string
    while (*str)
    {
        if (*str < '0' || *str > '9')
        {
            break; // If the char isn´t an integer, stop the convertion
        }
        result = result * 10 + (*str - '0');
        str++;
    }
    return sign * result;
}

// Function to open a semaphore safely, looking for a free one
int 
open_semaphore(int value)
{
    int sem_id = -1;
    // Starts in 1, 0 is reserved
    for (int i = 1; i < MAX_SEMS; i++)
    { 
        if (sem_open(i, value) == i)
        {
            sem_id = i;
            break;
        }
    }
    return sem_id;
}

// Auxiliar function to compare strings
int 
my_strcmp(const char *s1, const char *s2) 
{
    while (*s1 && (*s1 == *s2))
    {
        s1++;
        s2++;
    }
    return *(unsigned char *)s1 - *(unsigned char *)s2;
}

int 
main(int argc, char *argv[]) 
{

    int egg = 0;
    // Flag use
    if (argc == 3)
    {
        if (!my_strcmp(argv[2], "-f"))
        {
            egg = 1;
        }
        else 
        {
            printf ("ERROR: Incorrect flag.\n");
            return 1;
        }
    }

    else if (argc != 2) {
        printf("ERROR: Incorrect format.\n");
        exit(1);
    }
    int rally = atoi(argv[1]);
    if (rally < 1) {
        printf("ERROR: Value out of range.\n");
        exit(1);
    }

    int ping = open_semaphore(1);
    int pong = open_semaphore(0);
    
    if(ping == -1 || pong == -1)
    {
        printf("ERROR: No semaphores available.");
        return 1;
    }

    int pid = fork();
    if (pid < 0) 
    {
        printf("FORK ERROR\n");
        sem_close(ping);
        sem_close(pong);
        exit(1);
    }
    if (pid == 0) { // Child process
        for (int i = 0; i < rally; ++i)
        {
            sem_down(pong);
            !egg ? printf ("\tpong\n") : printf ("\t\t\tpong .·´¯`°ꟼ(•_• )\n\n");
            sem_up(ping);
        }
    } else { // Parent process
        for (int i = 0; i < rally; ++i)
        {
            sem_down(ping);
            !egg ? printf("ping\n") : printf ("( •_•)P*¯`·. ping\n");
            sem_up(pong);
        }
    }
    // Parent waits for the son to finish
    wait(0);
    // Close semaphores before their use
    sem_close(ping);
    sem_close(pong);
    return 0;
}