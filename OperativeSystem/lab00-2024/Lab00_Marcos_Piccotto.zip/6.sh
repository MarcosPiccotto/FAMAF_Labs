sort -k2,2nr -k7,7nr -k8,8n superliga.in | awk '{print $1, $2, $3, $4, $5, $6, $7, $8}' | cat
