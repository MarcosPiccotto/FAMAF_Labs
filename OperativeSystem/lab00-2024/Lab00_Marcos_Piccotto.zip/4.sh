sort -k5,5nr weather_cordoba.in | head -n 1 | awk '{print $1, $2, $3}';sort -k6,6n weather_cordoba.in | head -n 1 | awk '{print $1, $2, $3}'

