grep 'model name' /proc/cpuinfo

