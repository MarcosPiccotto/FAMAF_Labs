curl https://raw.githubusercontent.com/dariomalchiodi/superhero-datascience/master/content/data/heroes.csv | awk -F';' '{print tolower($2) | "tr -d \" \""}' | grep -v '^$'
