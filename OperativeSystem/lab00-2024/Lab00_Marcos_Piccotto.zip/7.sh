ip link show enp1s0 | grep -o -E '([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}'
